Tasks cleared : 
	File Input using Command Line arguments.
	Simulations of I-Cache :
		1. Filling all lines. (all misses)
		2. Certain hits.
		3. Eviction using LRU. 
		4. Generating Hit and Miss Count.

Tasks Remaining:
	Output file generation
	Mode select.
	Event merging
	Simulation of Data Cache.
	Integrating MESI protocol
	.....