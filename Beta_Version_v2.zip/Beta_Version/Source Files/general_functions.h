/* ------------------------------------------------------------------
Header File for General_Functions.c


-------------------------------------------------------------------*/
#include <stdio.h>
#include "cache_parameters.h"

//#define General_Functions

// Variable to declare Index Split bits
int Index_Split (unsigned long address);

