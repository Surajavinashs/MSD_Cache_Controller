#include <stdio.h>

#include "cache_parameters.h"




// Variable to declare MESI protocol
void MESI(int event, int index, int way, unsigned long address);