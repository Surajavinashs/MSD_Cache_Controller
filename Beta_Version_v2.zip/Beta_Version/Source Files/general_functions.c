/*-----------------------------------------------------------------
instruction_cache_functions.c : Contails  functions for simulation
 					  of Instruction Cache.


-------------------------------------------------------------*/
// Defining Required libraries

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

// Defining required functions files
#include "cache_parameters.h"

// Instruction cache Index and Byte select bits
int Index_Bits = 14;//log2(I_INDEX);
int Byte_Sel = 6;//log2(I_LINESIZE);

//---------------Split Index Bits from the address--------------
// Splits or Masks the the Index Bits from the netire address 
int Index_Split (unsigned long address)
	{
		int i;
		int split = 1;								// Initializing split parameter to 1
		int index;
		address = address >> Byte_Sel;              // istream Operator Segregates Byte_Sel from the trace address
	// Now we can operate on our leftover address which is without the Byte_Sel bits
		for (i=0; i<Index_Bits; i++)
		{
			split = split *2;
		}
		index = address & (split-1);
		return index;
	}
