




#include <stdio.h>
#include <stdlib.h>

#include "data_cache_functions.h"



extern struct cacheline Data_Cache[D_INDEX][D_WAY];
	
void MESI(int event, int index, int way, unsigned long address)
{
		switch (Data_Cache[index][way].MESI)
		{
		case I:			// read	data	request	to L1 data cache
			if ((event == D_L1_Read))	  // event 0
			{
				Data_Cache[index][way].MESI = S;           // L2 - E
				//fprintf(outfile, "Read from	L2 %x  and MESI = S \n", address);
			}

			//Read	for	Ownership	from	L2 - WRITE THROUGH as it is first write
			else if (event == D_L1_Write) // RFO
			{
				Data_Cache[index][way].MESI = E;            // L2 - M
				//fprintf(outfile, "Read for Ownership from L2 %x and MESI = E\n", address);
			}

			// Invalidate command from L2
			else if (event == INVALIDATE) // event 3
			{
				Data_Cache[index][way].MESI = I;			//L2- I
				//#ifdef DEBUG
				fprintf(outfile, "Invalidating the cache line  %x  and MESI = I\n", address);
				//#endif // DEBUG
			}

			// incorrect commands: read request from L2,  
			else
			{
				Data_Cache[index][way].MESI = I;
				fprintf(outfile, "ERROR: Incorrect Request\n");
			}
			break;

		case S:     // read data	request	to L1 data cache
			if (event == D_L1_Read)       // event 0
			{
				Data_Cache[index][way].MESI = S;
				//#ifdef DEBUG
				//fprintf(outfile, "read from %x and MESI = S\n", address);
				//#endif // DEBUG
			}

			// invalidate	command	from	L2
			else if (event == INVALIDATE)  // event 3
			{
				for (int temp_way = 0; temp_way < D_WAY - 1; temp_way++)
				{
					if (Data_Cache[index][temp_way].TAG == tag)
					{
						Data_Cache[index][temp_way].MESI = I;
						#ifdef DEBUG
						//fprintf(outfile, "Invalidating the line\n");
						#endif // DEBUG
					}
				}
				#ifdef DEBUG
				fprintf(outfile, "Invalidating the cache line  %x and MESI = I\n", address);
				#endif // DEBUG
			}

			// write	data	request	to L1	data	cache
			else if (event == D_L1_Write)   // event 1
			{
				Data_Cache[index][way].MESI = E;
				fprintf(outfile, "Write to L2 %x and MESI = E\n", address);
			}

			// Invalid commands: read request frm L2
			else
			{
				Data_Cache[index][way].MESI = S;
				fprintf(outfile, "ERROR: Incorrect Request\n");
			}
			break;


		case E:     // read data	request	to L1 data cache
			if (event == D_L1_Read)       // event 0
			{
				Data_Cache[index][way].MESI = E;
				//#ifdef DEBUG
				fprintf(outfile, "read from %x and MESI = E\n", address);
				//#endif // DEBUG
			}

			//data	request	from	L2(in	response	to	snoop)
			else if (event == D_L2_Read)  // event 4
			{
				Data_Cache[index][way].MESI = S;
				fprintf(outfile, "Return data to L2 %x and MESI = S\n", address);
			}

			// invalidate	command	from	L2
			else if (event == INVALIDATE)  // event 3
			{
				int temp_way;
				for (temp_way = 0; temp_way < D_WAY - 1; temp_way++)
				{
					if (Data_Cache[index][temp_way].TAG == tag)
					{
						Data_Cache[index][temp_way].MESI = I;
						#ifdef DEBUG
						//fprintf(outfile, "Invalidating the line\n");
						#endif // DEBUG
					}
				}

			}

			// write	data	request	to L1	data	cache
			else if (event == D_L1_Write)   // event 1
			{
				Data_Cache[index][way].MESI = M;
				#ifdef DEBUG
				fprintf(outfile, "Modilfy the cache line in L1 %x and MESI = I \n", address);
				#endif // DEBUG
			}

			else
			{
				Data_Cache[index][way].MESI = E;
				fprintf(outfile, "ERROR: Incorrect Request\n");
			}

			break;

		case M:		// L1 read OR L1 write
			if ((event == D_L1_Read) || (event == D_L1_Write))          // event 0 or event 1
			{
				Data_Cache[index][way].MESI = M;
				#ifdef DEBUG
				fprintf(outfile, "Read from L1 or Write to L1 %x \n", address);
				#endif // DEBUG
			}

			//data	request	from	L2(in	response	to	snoop)
			else if (event == D_L2_Read)  // event 4
			{
				Data_Cache[index][way].MESI = S;
				fprintf(outfile, "Return data to L2 %x and MESI = S\n", address);
			}

			// invalidate	command	from	L2
			else if (event == INVALIDATE)  // event 3
			{
				Data_Cache[index][way].MESI = M;
				#ifdef DEBUG
				fprintf(outfile, "Impossible command. Cannot invalidate a modified line\n");
			#endif // DEBUG
			}

			else
			{
				Data_Cache[index][way].MESI = E;
				fprintf(outfile, "ERROR: Incorrect Request\n");
			}

			break;
		default:  fprintf(outfile, "INCORRECT STATE");

		}
	}

