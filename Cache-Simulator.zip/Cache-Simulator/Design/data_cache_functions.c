
/*----------------------------------------------------------------------------------------------------------------------
data_cache_functions.c : 
- Contails functions for simulation of Data Cache.
- Data_Read        => Navigates between hit check and miss handler function to detect a Hit or a Miss.
- D_Hit_Check      => Checks if the the access made to an address is a Hit or not and return aapropriate values.
- D_Miss_Handler   => Updates MESI TAG and LRU bits in case of a miss.
- D_Clear_Cache    => Used to clear the contents of the cache upon RESET command.
- D_Update_LRU     => Used to update the LRU bits of a selected line
- D_Evict_Line_LRU => Handles Eviction of a line and updates the LRU on Eviction
- D_Statictics     => UUsed to print the statisctics of the Data Cache 
 
 Authors:
 @Ajna Bindhu,
 @Sai T Bodanki
 @Suraj A Sathyanarayanan
 @Tejas Chavan

-----------------------------------------------------------------------------------------------------------------------*/
// Defining Required libraries

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
// Defining required functions files
#include "cache_parameters.h"
#include "data_cache_functions.h"
#include "general_functions.h"

/*-----------------Data Read Block------------------------------------------------------------------------
This function navigates the flow of the program. If the Hit check function returns 0 , then it calls miss 
handler function .
If the miss handler returns a 0, it calls evict line LRu function.  
----------------------------------------------------------------------------------------------------------*/

int
Data_Read (int index, int tag)
{  
  // If not a HIT
  if (!(D_Hit_Check (index, tag)))            
    {
      // If MISS and all the ways are FULL. call evict_line_LRU
      if (!(D_Miss_Handler (index, tag)))     
  {
    D_Evict_Line_LRU (index, tag);
  }
      // Return 0 on after handling a MISS
      return 0;                               
    }
  // Return 1 after handling a HIT
  return 1;                                   
}

//--------------HIT Check block---------------------------------------------------------------
//This Block checks if the input TAG match as well as if the the state is invalid or not for both ways in a for loop
// If Both the conditions are satisfied, it enters the loop, calls the D_updateLRU function and returns 1 
//----------------------------------------------------------------------------------------------
int
D_Hit_Check (int index, int tag)
{
  for (way = 0; way < D_WAY; way++)
    {
    // Check  if the tag bits match and if the State is not invalid
      if ((Data_Cache[index][way].TAG == tag)
	    && (Data_Cache[index][way].MESI != I))
	   {  
	   D_updateLRU (index, way);
	   return 1;
	   }
      else if (way == D_WAY - 1)
	   return 0;
    }
  return 3;
}

/*--------------Miss Handling block---------------------------------------------------------------
This function checks if the MESI state is invalid or not. if yes then it updates the address and
tag bits and calls the update LRu function.
If the MESI is not invalid and if the way is equal to maximimum ways of the cache 
then it might lead to eviction and hence the function returns 0 
------------------------------------------------------------------------------------------------*/

int
D_Miss_Handler (int index, int tag)
{

  for (way = 0; way < D_WAY; way++)
    {
      if (Data_Cache[index][way].MESI == I)
	    {
	     Data_Cache[index][way].ADDRESS = address;
	     Data_Cache[index][way].TAG = tag;
	     D_updateLRU (index, way);
	     return 1;
	    }
      else if (way == D_WAY - 1)
	    return 0;
    }
    return 3;
}


/*-------------------Update LRU Block----------------------------------------------------------------
This function updates the LRU bits upon receiving an read or write request from the processor.
If the LRU bit is aleady 0, then it does nothing bt if the LRU bits are other than 0 then updates it
---------------------------------------------------------------------------------------------------*/
void
D_updateLRU (int index, int way)
{
  // if the LRU bits of our way are already the most recently used, we do nothing
  if (Data_Cache[index][way].LRU == 0)
    return;
  else
    {
      int current_lru = Data_Cache[index][way].LRU;
      int temp_way;

      for (temp_way = 0; temp_way <= D_WAY - 1; temp_way++)
	    {
	    if (Data_Cache[index][temp_way].LRU < current_lru)
	    Data_Cache[index][temp_way].LRU++;
	    }
    }
  Data_Cache[index][way].LRU = 0;
}

/*---------------------Evict Line LRU Block----------------------------------------------------
This function evicts the Least recently used cache line.
Moreover if the cache line to be evicted in in M state, the it first write backs to the L2 and
then evicts the line from itself
---------------------------------------------------------------------------------------------*/

void
D_Evict_Line_LRU (int index, int tag)
{
  evict_flag = 1;
  for (way = 0; way <= D_WAY - 1; way++)
    {
      if (Data_Cache[index][way].LRU == D_WAY - 1)
	  {
	    if (Data_Cache[index][way].MESI == M)
	    {
	      Data_Cache[index][way].TAG = tag;

	      D_updateLRU (index, way);

	      if (mode_sel == 1)
		{
      if (event == 1)
      {
        fprintf (outfile, "Write to L2                <0x%08x>\n",
          Data_Cache[index][way].ADDRESS);
      fprintf (outfile, "Read for ownership from L2 <0x%08x>\n", address);
      }
      else if (event == 0)
      { 
		  fprintf (outfile, "Write to L2                <0x%08x>\n",
					Data_Cache[index][way].ADDRESS);
		  fprintf (outfile, "Read from L2               <0x%08x>\n", address);
		  }
    } 
	      Data_Cache[index][way].ADDRESS = address;

	    }
	  else
	    {
	    if (mode_sel == 1)
			{
        if (event == 1)
        {
        fprintf (outfile, "Read for ownership for L2  <0x%08x>\n", address);
        }
        else if (event == 0)
        {
		  	fprintf (outfile, "Read from L2               <0x%08x>\n", address);
			  }
      }
	      Data_Cache[index][way].TAG = tag;
	      D_updateLRU (index, way);
	      Data_Cache[index][way].ADDRESS = address;
	    }
	  break;
	}
    }
}

/*---------------Clear Cache Block-----------------------------------------------------------------
This function clears the entire content of the cache by checking for index and way and makes the MESI 
bit invalid. 
Also it resets the LRU to 3 
-------------------------------------------------------------------------------------------------*/
void
D_Clear_Cache (void)
{

  int index;
  int way;
  d_hit = 0;
  d_miss = 0;
  for (index = 0; index <= D_SETS; index++)
    {
      for (way = 0; way < D_WAY; way++)
	   {
	    Data_Cache[index][way].MESI = I;
	    Data_Cache[index][way].LRU = D_WAY - 1;
	   }
    }
}

/*----------------------------------Display data cache contents-------------------------------
This function display the cache Line contents including its index, way, MESI, LRU and TAG bits
--------------------------------------------------------------------------------------------*/

void D_Statistics ()
{
        fprintf(outfile,"------------------Data Cache------------------\n");
                for (int d_index = 0; d_index < D_SETS; d_index++)
                    
                {
                    
                    for (int d_ways = 0; d_ways < D_WAY; d_ways++)
                    {
                        
                        if (Data_Cache[d_index][d_ways].MESI != I)
                            
                            fprintf (outfile,
                                    "Index:%05d,WAY:%d,MESI:%c,LRU:%02d,TAG:0x%08x\n",
                                     d_index, d_ways,
                                     mesi_state (Data_Cache[d_index][d_ways].
                                                 MESI),
                                     Data_Cache[d_index][d_ways].LRU,
                                     Data_Cache[d_index][d_ways].TAG);

                        
                    }
                    
                }               
}
