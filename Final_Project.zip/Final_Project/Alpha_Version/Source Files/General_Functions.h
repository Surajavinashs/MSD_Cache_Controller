/* ------------------------------------------------------------------
Header File for General_Functions.c


-------------------------------------------------------------------*/
#include <stdio.h>
#include "cache_parameters.h"

#define General_Functions

extern FILE *outfile;
extern int Index_Bits;
extern int Byte_Sel;
extern struct cacheline Instr_Cache[I_INDEX][I_WAY];


// Variable to declare Index Split bits
int Index_Split (unsigned long address);

// Variable to Match tag bits
//int Match_Tag_Bits(int index, int tag, int *hit);

void updateLRU(int index, int way);

void Clear_Cache(void);

int Miss_Handler(int index, int tag);

int Hit_Check(int index, int tag);

int Instruction_Read(int index, int tag);

void Evict_Line_LRU(int index, int tag);