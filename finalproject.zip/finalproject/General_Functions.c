/*-----------------------------------------------------------------
General_Functions.c : Contails generalized functions for simulation 
					  of Cache.


-------------------------------------------------------------*/
// Defining Required libraries

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>



// Defining required functions files
#include "General_Functions.h"
#include "cache_parameters.h"

// Instruction cache Index and Byte select bits
int Index_Bits = 14;//log2(I_INDEX);
int Byte_Sel = 6;//log2(I_LINESIZE);

extern struct cacheline Instr_Cache[I_INDEX][I_WAY]; 



//---------------Split Index Bits from the address--------------
// Splits or Masks the the Index Bits from the netire address 
int Index_Split (unsigned long address)
	{
		int i;
		int split = 1;								// Initializing split parameter to 1
		int index;
		address = address >> Byte_Sel;              // istream Operator Segregates Byte_Sel from the trace address
	// Now we can operate on our leftover address which is without the Byte_Sel bits
		for (i=0; i<Index_Bits; i++)
		{
			split = split *2;
		}
		index = address & (split-1);
		return index;
	}
/**
//--------------Checking for Tag Bits----------------------------
int Match_Tag_Bits (int index, int tag, int *hit)
	{
		int way;
			for (way = 0; way < I_WAY; way++)
			{
				if((Instr_Cache[index][way].TAG == tag))
//				if ((Instr_Cache[index][way].TAG == tag) //&& (Instr_Cache[index][way].MESI != I)) 
				{
					fprintf(outfile, "\n---------HIT-----------\n");
					(*hit)++;
					return way;
				}
			}
			return (I_WAY + 1);
	
	}
	*/


