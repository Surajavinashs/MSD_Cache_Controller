/*---------------------------------------------------------------------------------------------------------------------
Description: 
Authors: Bindu Ajna
		 Bodanki Sai Teja
		 Chavan Tejas
		 Sathyanarayanan Suraj
---------------------------------------------------------------------------------------------------------------------*/

// Declaring Standard Libraries
#define _CRT_SECURE_NO_DEPRECATE
#include <stdio.h>
#include <stdlib.h>
#include "cache_parameters.h"
#include "General_Functions.h"
#include "General_Functions.c"

//Define 2 character pointer to accept input and output filesnames

FILE *outfile;  		//	Output File pointer
FILE *infile;			//  Input File Pointer
unsigned long  event, address;
const char *input;
const char *output;
int hit = 0;			// Variable for Hit and miss count initialized to 0
int miss = 0; 

// Declaring Structure For Instruction Cache
struct cacheline Instr_Cache[I_INDEX][I_WAY];

// Declaration of Main Function
int main (int argc, char * argv[])
{
	// I/O files are taken using Command Line arguments 
	// Case 1 : No file names are mentioned. 
	if (argc == 1)
		{
			printf("I/O files are not mentioned. Using default files as inputs and Outputs\n");
			input  = "default.txt";
			output = "output.txt";
		}
	// Case 2 : Only Input File name is provided. Default Output file is created.
	else if (argc == 2)
		{
			printf("Input file will be named as mentioned. Output file will be defaulted to output.txt\n");
			input  = argv[1];
			output = "output.txt";
		}
	// Case 3 : Both Input and Output file names are mentioned		
	else 
		{
			input  = argv[1];
			output = argv[2];
		}


// Opening Input and Output file in read and write mode respectively
		infile  = fopen(input, "r");							// Read Mode
		outfile = fopen(output, "w"); 							// Write Mode 

	while ((fscanf (infile, "%d %x\n", &event, &address) != EOF))
	//for(;;)
		{
		//scanf("%x", &address);
		printf("%lu %x9 \n", address, address);
		fprintf (outfile, "EVENT = %d \t ADDRESS: %x \n", event, address);
		int index = +Index_Split(address);

		int tag_rem = Byte_Sel + Index_Bits;

		int tag = address >> tag_rem;

		//printf("index %d, tag_rem %d, tag %d, address %d", index, tag_rem, tag,address);

		fprintf(outfile, "Index: %d, Tag Rem %d, Tag %d \n", index, tag_rem, tag);
	}

	fclose(infile);
	fclose(outfile);

	getchar();
}
