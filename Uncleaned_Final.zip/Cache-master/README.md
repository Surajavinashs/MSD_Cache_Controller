
# Compile and Exicute

The following files are used to compile
cache.c
data_cache_functions.c
instruction_cache_functions.c
general_functions.c
MESI_v2.c

Compile by the command
gcc -o cache main.c data_cache_functions.c instruction_cache_functions.c general_functions.c MESI_v2.c

Run by using promt

./executable input-file(Mandatory) Mode(optional-0-by default) Output-file(optional)

example:
./cache input.txt 1

# Cache-Simulator
This program simulates a Data and Instruction L1 cache with MESI protocol

# Compiling and Executing the program

yet to write

This code was compiled by using a gcc v.6.2.
./cache input-file mode output-file(optional)

# Cache Details
Instruction cache has capacity if 2MB and Data cache has a cpacity of 4MB
The following cache properties can the changed by redefining the macros
-CAPACITY
-LINESIZE
-WAY (Number of ways)
during compilation

# Authors:
Authors: Bindu Ajna
Bodanki Sai Teja
Chavan Tejas
Sathyanarayanan Suraj
