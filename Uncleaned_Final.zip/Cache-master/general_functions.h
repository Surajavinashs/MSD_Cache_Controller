/* ------------------------------------------------------------------
Header File for General_Functions.c

 Authors:
 @Ajna Bindhu,
 @Sai T Bodanki
 @Suraj A Sathyanarayanan
 @Tejas Chavan
-------------------------------------------------------------------*/
#include <stdio.h>
#include "cache_parameters.h"

//#define General_Functions

// Variable to declare Index Split bits
int Index_Split (unsigned long address);

void bits_cal();

char mesi_state(int mesi_int);
