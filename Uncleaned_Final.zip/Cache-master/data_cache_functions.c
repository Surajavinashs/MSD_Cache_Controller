
/*-----------------------------------------------------------------
instruction_cache_functions.c : Contails  functions for simulation
 					  of Instruction Cache.
 Authors:
 @Ajna Bindhu,
 @Sai T Bodanki
 @Suraj A Sathyanarayanan
 @Tejas Chavan

-------------------------------------------------------------*/
// Defining Required libraries

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>


// Defining required functions files
#include "cache_parameters.h"
#include "data_cache_functions.h"

//--------------HIT Check block---------------------------------------------------------------
//This Block checks if the input TAG match as well as if the the state is invalid or not for both ways in a for loop
// If Both the conditions are satisfied, it enters the loop, calls the D_updateLRU function and returns 1 
//----------------------------------------------------------------------------------------------
int D_Hit_Check(int index, int tag)
{
	for (way = 0; way < D_WAY; way++)
	{
		if ((Data_Cache[index][way].TAG == tag) && (Data_Cache[index][way].MESI != I))
		{
			D_updateLRU(index, way);
			return 1;
		}
		else if (way == D_WAY - 1)
			return 0;
	}return 3;
}

//--------------Miss Handling block---------------------------------------------------------------

int D_Miss_Handler(int index, int tag)
{
	for (way = 0; way < D_WAY; way++)
	{
		if (Data_Cache[index][way].MESI == I)
		{
			//get_lru function goes here
			Data_Cache[index][way].TAG = tag;
			D_updateLRU(index, way);
			return 1;
		}
		else if (way==D_WAY-1)
			return 0;
	}return 3;
}

//-----------------Instruction Read Block-----------------------------------------------------------

int Data_Read(int index, int tag)
{
	if (!(D_Hit_Check(index, tag)))
	{
		if (!(D_Miss_Handler(index, tag)))
		{
			D_Evict_Line_LRU(index, tag);
		}
		return 0;
	}
	return 1;
}

		
//---------------Clear Cache Block-----------------------------------------------------------------

void D_Clear_Cache(void)
{

	int index;
	int way;
	d_hit = 0;
	d_miss = 0;
	for (index = 0; index <= D_SETS; index++)
	{
		for (way = 0; way < D_WAY; way++)
		{
			Data_Cache[index][way].MESI = I;
			Data_Cache[index][way].LRU = D_WAY - 1;
		}
	}
}

//-------------------Update LRU Block----------------------------------------------------------------

void D_updateLRU(int index, int way)
{
	// if the LRU bits of our way are already the most recently used, we do nothing
	if (Data_Cache[index][way].LRU == 0)
		return;
	else
	{
		int ourbits = Data_Cache[index][way].LRU;
		int testway;

		for (testway = 0; testway <= D_WAY - 1; testway++)
		{
			if (Data_Cache[index][testway].LRU < ourbits)
				Data_Cache[index][testway].LRU++;
		}
	}
	Data_Cache[index][way].LRU = 0;
}

//---------------------Evict Line LRU Block----------------------------------------------------

void D_Evict_Line_LRU(int index, int tag)
{
	int temp_way;
	for (temp_way = 0; temp_way <= D_WAY - 1; temp_way++)
	{
		if (Data_Cache[index][temp_way].LRU == D_WAY - 1)
		{
            if (Data_Cache[index][temp_way].MESI == M)
            {
                Data_Cache[index][temp_way].TAG = tag;
                D_updateLRU(index, temp_way);
                 if(mode_sel==1){
            	 fprintf(outfile,"Write to L2 %x:\n",address);}
            }
            else{
			Data_Cache[index][temp_way].TAG = tag;
			D_updateLRU(index, temp_way);
            }
            break;
        }
    }
}

void D_Statistics(int hit,int miss,float hit_ratio)
{

}


