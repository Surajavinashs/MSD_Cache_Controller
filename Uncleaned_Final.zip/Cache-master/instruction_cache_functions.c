/*-----------------------------------------------------------------
instruction_cache_functions.c : Contails  functions for simulation
 					  of Instruction Cache.

 Authors:
 @Ajna Bindhu,
 @Sai T Bodanki
 @Suraj A Sathyanarayanan
 @Tejas Chavan
-------------------------------------------------------------*/
// Defining Required libraries

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

// Defining required functions files
#include "cache_parameters.h"
#include "instruction_cache_functions.h"

 
//--------------HIT Check block---------------------------------------------------------------
//This Block checks if the input TAG match as well as if the the state is invalid or not for both ways in a for loop
// If Both the conditions are satisfied, it enters the loop, calls the I_updateLRU function and returns 1 
//----------------------------------------------------------------------------------------------
int I_Hit_Check(int index, int tag)
{
	int way;
	for (way = 0; way < I_WAY; way++)
	{
		if ((Instr_Cache[index][way].TAG == tag) && (Instr_Cache[index][way].MESI != I))
		{		
			I_updateLRU(index, way);
			return 1;
		}
		else if (way == I_WAY - 1)
			return 0;
	}return 3;
}

//--------------Miss Handling block---------------------------------------------------------------

int I_Miss_Handler(int index, int tag)
{
	int way;
	for (way = 0; way < I_WAY; way++)
	{
		if (Instr_Cache[index][way].MESI == I)
		{
			//get_lru function goes here
			Instr_Cache[index][way].MESI = S;
			Instr_Cache[index][way].TAG = tag;
			I_updateLRU(index, way);
            if(mode_sel==1){
            fprintf(outfile, "Read from L2 %x\n", address);
            }
            return 1;
		}
		else if (way==I_WAY-1)
			return 0;

	}return 3;
}

//-----------------Instruction Read Block-----------------------------------------------------------

int Instruction_Read(int index, int tag)
{
	if (!(I_Hit_Check(index, tag)))
	{
		if (!(I_Miss_Handler(index, tag)))
		{
			I_Evict_Line_LRU(index, tag);
		}
		return 0;
	}
	return 1;
}

		
//---------------Clear Cache Block-----------------------------------------------------------------

void I_Clear_Cache(void)
{

	int index;
	int way;
	int i_miss = 0;
	int i_hit = 0;
	for (index = 0; index <= I_SETS; index++)
	{
		for (way = 0; way < I_WAY; way++)
		{
			Instr_Cache[index][way].MESI = I;
			Instr_Cache[index][way].LRU = I_WAY - 1;
		}
	}
}

//-------------------Update LRU Block----------------------------------------------------------------

void I_updateLRU(int index, int way)
{
	// if the LRU bits of our way are already the most recently used, we do nothing
	if (Instr_Cache[index][way].LRU == 0)
		return;
	else
	{
		int ourbits = Instr_Cache[index][way].LRU;
		int testway;

		for (testway = 0; testway <= I_WAY - 1; testway++)
		{
			if (Instr_Cache[index][testway].LRU < ourbits)
				Instr_Cache[index][testway].LRU++;
		}
	}
	Instr_Cache[index][way].LRU = 0;
}

//---------------------Evict Line LRU Block----------------------------------------------------

void I_Evict_Line_LRU(int index, int tag)
{
	int way;
	for (way = 0; way <= I_WAY - 1; way++)
	{
		if (Instr_Cache[index][way].LRU == I_WAY - 1)
			//Here You also need to check if the state is MODIFIED or not.
			// IF yes, then you need to write back the data to L2 cache.
		{
			Instr_Cache[index][way].TAG = tag;
			I_updateLRU(index, way);
            if(mode_sel==1){
            fprintf(outfile, "Read from L2 %x\n", address);
            }
			break;
		}
	}
}

void I_Statistics(int hit,int miss,float hit_ratio)
{
}
