/*---------------------------------------------------------------------------------------------------------------------
Description:
Authors: Bindu Ajna
Bodanki Sai Teja
Chavan Tejas
Sathyanarayanan Suraj
---------------------------------------------------------------------------------------------------------------------*/

// Declaring Standard Libraries
#include <stdio.h>
#include <stdlib.h>
#include "cache_parameters.h"
#include "general_functions.h"
#include "instruction_cache_functions.h"
#include "data_cache_functions.h"
#include <math.h>
#include <string.h>
#define MAX_LINE_SIZE 1000
#define DEBUG_MODE

//File Acess
FILE *outfile;  		//	Output File pointer
FILE *infile;			//  Input File Pointer
const char *input;
const char *output;
//Data types
int event, address;
int d_rd, d_wr, i_rd = 0;
int i_hit = 0,d_hit=0;			// Variable for Hit and miss count initialized to 0
int i_miss = 0,d_miss=0;
int way;
int tag;
int line_size,index_size;
const char *mode;
int mode_sel;
const char s[2] = " ";
char *token;
int i;
int arr[2];
char line[MAX_LINE_SIZE+1]; // ptr to the current input line


// Declaring Structure For Instruction Cache
struct cacheline Instr_Cache[I_SETS][I_WAY];
struct cacheline Data_Cache [D_SETS][D_WAY];

// Declaration of Main Function
int main(int argc, char * argv[])
{
	// I/O files are taken using Command Line arguments 
	// Case 1 : No file names are mentioned. 
	if (argc == 1)
	{
		printf("I/O files,modes are not mentioned. Using default files as inputs and Outputs\n");
		input = "Cache_fill.txt";
		output = "output.txt";
        mode = "0";
	}
	// Case 2 : Only Input File name is provided. Default Output file is created.
	else if (argc == 2)
	{
		printf("Input file will be named as mentioned. Output file will be defaulted to output.txt\n");
		input = argv[1];
        mode  = "0";
		output = "output.txt";
	}
    else if (argc == 3)
    {
        printf("Input file will be named as mentioned. Output file will be defaulted to output.txt\n");
        input = argv[1];
        mode  = argv[2];
        output = "output.txt";
    }
	// Case 3 : Both Input and Output file names are mentioned
	else
	{
		input  = argv[1];
        mode   = argv[2];
		output = argv[3];
	}
	// Opening Input and Output file in read and write mode respectively
	infile = fopen(input, "r");							// Read Mode
	outfile = fopen(output, "w"); 							// Write Mode 

	I_Clear_Cache();
	D_Clear_Cache();

    char mode_char = *mode;
    mode_sel = (int) mode_char - 48;
    
    while(fgets(line, sizeof(line), infile) != NULL){

        if (feof(infile))
        break;
        if (line[0] != '\n'){
        i=0;
        token = strtok(line, s);
        while( token != NULL ) {
        arr[i] = (int) strtol(token, NULL, 16);
        token = strtok(NULL, s);
        i++;
        }
            event = arr[0];
            address = arr[1];
		// Split Address
        bits_cal();
		int index = +Index_Split(address);
		int tag_rem = (int) log2(line_size) + (int) log2(index_size);
        //int tag_bits =  8*sizeof(address) - tag_rem;
		tag = address >> tag_rem;
            
		//Detect and report invalid event
		if ((event > 4) && (event < 8))
		{
			fprintf(outfile, "Invalid Event\n");
			continue;
		}
		//Detect reads
		else if (event == D_L1_Read)
		{
			if ((Data_Read(index, tag))) {
				d_hit++;
			}
			else {
				d_miss++;
			}
			MESI(event, index, address);
		}
		//Detect writes
		else if (event == D_L1_Write)
		{
			if ((Data_Read(index, tag))) {
				d_hit++;
			}
			else {
				d_miss++;
			}
			MESI(event, index, address);
		}
		// Detect Instruction read
		else if (event == I_L1_READ)
		{
			i_rd++;
			if ((Instruction_Read(index, tag))) {
				i_hit++;
			}
			else {
				i_miss++;
			}
            
		}


		// Data request from L2 (in response to snoop)
		else if (event == D_L2_Read)
		{
				MESI(event, index, address);
		}


		//Detect INVALIDATE command from L2
		else if (event == INVALIDATE)
		{
			MESI(event, index, address);
		}
            
		//Detect reset event
		else if (event == RESET)
		{
			I_Clear_Cache();
			D_Clear_Cache();
			continue;
		}
            
		//Detect cache display event 
		else if (event == PRINTALL)
		{
            for(int i_index=0;i_index<I_SETS;i_index++)
            {
                for(int i_ways=0;i_ways<I_WAY;i_ways++)
                    if(Instr_Cache[i_index][i_ways].MESI!=I)
                        fprintf(outfile,"I Cache,Index:%d,WAY:%d,MESI:%c, LRU:%d,TAG: %d\n",i_index,i_ways,mesi_state(Instr_Cache[i_index][i_ways].MESI),Instr_Cache[i_index][i_ways].LRU,Instr_Cache[i_index][i_ways].TAG);
            }
            
            for(int d_index=0;d_index<D_SETS;d_index++)
            {
                for(int d_ways=0;d_ways<D_WAY;d_ways++){
                if(Data_Cache[d_index][d_ways].MESI!=I)
                        fprintf(outfile,"D Cache,Index:%d,WAY:%d,MESI:%c, LRU:%d,TAG: %d\n",d_index,d_ways,mesi_state(Data_Cache[d_index][d_ways].MESI),Data_Cache[d_index][d_ways].LRU,Data_Cache[d_index][d_ways].TAG);
                }
            }
			continue;
          }
        }
    
    }

    float i_hit_ratio  = 0;
    float d_hit_ratio = 0;
    
    if(i_miss > 0){
    i_hit_ratio = ((float)(i_hit)) / ((float)(i_miss));
    }
    
    if (d_miss>0) {
    d_hit_ratio = ((float)(d_hit)) / ((float)(d_miss));
    }
    
	fclose(infile);
	fclose(outfile);
    
    printf("\n-------------Instruction Cache Stats---------\n");
    printf(" Hits : %d \n", i_hit);
    printf(" Miss : %d \n", i_miss);
    printf(" Hit Ratio : %3f", i_hit_ratio);
    
    printf("\n-------------Data Cache Stats---------\n");
    printf(" Hits : %d \n", d_hit);
    printf(" Miss : %d \n", d_miss);
    printf(" Hit Ratio : %3f", d_hit_ratio);
	getchar();
}
    
