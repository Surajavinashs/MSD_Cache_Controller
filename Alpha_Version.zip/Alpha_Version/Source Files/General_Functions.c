/*-----------------------------------------------------------------
General_Functions.c : Contails generalized functions for simulation 
					  of Cache.


-------------------------------------------------------------*/
// Defining Required libraries

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

// Defining required functions files
#include "General_Functions.h"
#include "cache_parameters.h"

// Instruction cache Index and Byte select bits
int Index_Bits = 14;//log2(I_INDEX);
int Byte_Sel = 6;//log2(I_LINESIZE);

//---------------Split Index Bits from the address--------------
// Splits or Masks the the Index Bits from the netire address 
int Index_Split (unsigned long address)
	{
		int i;
		int split = 1;								// Initializing split parameter to 1
		int index;
		address = address >> Byte_Sel;              // istream Operator Segregates Byte_Sel from the trace address
	// Now we can operate on our leftover address which is without the Byte_Sel bits
		for (i=0; i<Index_Bits; i++)
		{
			split = split *2;
		}
		index = address & (split-1);
		return index;
	}

 
//--------------HIT Check block---------------------------------------------------------------
//This Block checks if the input TAG match as well as if the the state is invalid or not for both ways in a for loop
// If Both the conditions are satisfied, it enters the loop, calls the updateLRU function and returns 1 
//----------------------------------------------------------------------------------------------
int Hit_Check(int index, int tag)
{
	int way;
	for (way = 0; way < I_WAY; way++)
	{
		if ((Instr_Cache[index][way].TAG == tag) && (Instr_Cache[index][way].MESI != I))
		{
			fprintf(outfile, "\n---------HIT-----------\n");
			//printf("\n---------HIT-----------\n");
		
			updateLRU(index, way);
			return 1;
		}
		else if (way == I_WAY - 1)
			return 0;
	}
}

//--------------Miss Handling block---------------------------------------------------------------

int Miss_Handler(int index, int tag)
{
	int way;
	for (way = 0; way < I_WAY; way++)
	{
		if (Instr_Cache[index][way].MESI == I)
		{
			//printf("\n---------MISS-----------\n");
			//get_lru function goes here
			Instr_Cache[index][way].MESI = E;
			Instr_Cache[index][way].TAG = tag;
			updateLRU(index, way);
			return 1;
		}
		else if (way==I_WAY-1)
			return 0;

	}
}

//-----------------Instruction Read Block-----------------------------------------------------------

int Instruction_Read(int index, int tag)
{
	if (!(Hit_Check(index, tag)))
	{
		if (!(Miss_Handler(index, tag)))
		{
			Evict_Line_LRU(index, tag);
		}
		fprintf(outfile, "\n---------MISS-----------\n");
		return 0;
	}
	return 1;
}

		
//---------------Clear Cache Block-----------------------------------------------------------------

void Clear_Cache(void)
{

	int index;
	int way;
	//fprintf(outfp, "\n**********Clearing Cache**********\n");
	for (index = 0; index <= I_INDEX; index++)
	{
		for (way = 0; way < I_WAY; way++)
		{
			Instr_Cache[index][way].MESI = I;
			Instr_Cache[index][way].LRU = I_WAY - 1;
		}
	}
}

//-------------------Update LRU Block----------------------------------------------------------------

void updateLRU(int index, int way)
{
	// if the LRU bits of our way are already the most recently used, we do nothing
	if (Instr_Cache[index][way].LRU == 0)
		return;
	else
	{
		int ourbits = Instr_Cache[index][way].LRU;
		int testway;

		for (testway = 0; testway <= I_WAY - 1; testway++)
		{
			if (Instr_Cache[index][testway].LRU < ourbits)
				Instr_Cache[index][testway].LRU++;
		}
	}
	Instr_Cache[index][way].LRU = 0;
}

//---------------------Evict Line LRU Block----------------------------------------------------

void Evict_Line_LRU(int index, int tag)
{
	int way;
	for (way = 0; way <= I_WAY - 1; way++)
	{
		if (Instr_Cache[index][way].LRU == I_WAY - 1)
			//Here You also need to check if the state is MODIFIED or not.
			// IF yes, then you need to write back the data to L2 cache.
		{
			Instr_Cache[index][way].TAG = tag;
			updateLRU(index, way);
			break;
		}
	}
}

void Statistics(int hit,int miss,int hit_ratio)
{

	fprintf(outfile, "HIT  COUNT = %d\n", hit);						// Miss Count
	fprintf(outfile, "MISS COUNT = %d\n", miss);						// Miss Count
	fprintf(outfile, "Hit Ratio : %3f", hit_ratio);
}