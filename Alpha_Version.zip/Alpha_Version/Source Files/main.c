/*---------------------------------------------------------------------------------------------------------------------
Description:
Authors: Bindu Ajna
Bodanki Sai Teja
Chavan Tejas
Sathyanarayanan Suraj
---------------------------------------------------------------------------------------------------------------------*/

// Declaring Standard Libraries
#include <stdio.h>
#include <stdlib.h>
#include "cache_parameters.h"
#include "General_Functions.h"

#define DEBUG_MODE

//File Acess
FILE *outfile;  		//	Output File pointer
FILE *infile;			//  Input File Pointer
const char *input;
const char *output;
//Data types
unsigned long event, address;
int d_rd, d_wr, i_rd = 0;
int hit = 0;			// Variable for Hit and miss count initialized to 0
int miss = 0;


// Declaring Structure For Instruction Cache
struct cacheline Instr_Cache[I_INDEX][I_WAY];

// Declaration of Main Function
int main(int argc, char * argv[])
{
	// I/O files are taken using Command Line arguments 
	// Case 1 : No file names are mentioned. 
	if (argc == 1)
	{
		printf("I/O files are not mentioned. Using default files as inputs and Outputs\n");
		input = "default.txt";
		output = "output.txt";
	}
	// Case 2 : Only Input File name is provided. Default Output file is created.
	else if (argc == 2)
	{
		printf("Input file will be named as mentioned. Output file will be defaulted to output.txt\n");
		input = argv[1];
		output = "output.txt";
	}
	// Case 3 : Both Input and Output file names are mentioned		
	else
	{
		input = argv[1];
		output = argv[2];
	}
	// Opening Input and Output file in read and write mode respectively
	infile = fopen(input, "r");							// Read Mode
	outfile = fopen(output, "w"); 							// Write Mode 

	Clear_Cache();

	while ((fscanf(infile, "%d %x\n", &event, &address) != EOF))
	{

		// Split Address
		int index = +Index_Split(address);
		int tag_rem = Byte_Sel + Index_Bits;
		int tag = address >> tag_rem;

		//Detect and report invalid event
		if ((event > 4) && (event < 8))
		{
			fprintf(outfile, "Invalid Event\n");
			continue;
		}
		//Detect reads
		else if (event == D_L1_Read)
		{
			d_rd++;
		}
		//Detect writes
		else if (event == D_L1_Write)
		{
			d_wr++;
		}
		else if (event == I_L1_READ)
		{
			i_rd++;
			if ((Instruction_Read(index, tag))) {
				hit++;
			}
			else {
				miss++;
			}
		}
		//Detect reset event
		else if (event == RESET)
		{
			Clear_Cache();
			continue;
		}
		//Detect cache display event 
		else if (event == PRINTALL)
		{
			//			Cache_Display();
			continue;
		}


		//-------------------------------Print to output file-----------------------------------------------
			fprintf(outfile, "Index = %d\n", index);						//Print Event
			fprintf(outfile, "Tag = %d\n",tag);					//Print Address

			for (int way = 0; way < I_WAY; way++)
			{
				fprintf(outfile, "Contents for way :%d LRU :%d TAG: %d\n", way,Instr_Cache[index][way].LRU, Instr_Cache[index][way].TAG);
			}

	}
	float hit_ratio = ((float)(hit)) / ((float)(hit + miss));
	Statistics(hit, miss, hit_ratio);
	printf(" Hits : %d \n", hit);
	printf(" Miss : %d \n", miss);
	printf(" Hit Ratio : %3f", hit_ratio);
	fclose(infile);
	fclose(outfile);
	getchar();

}
