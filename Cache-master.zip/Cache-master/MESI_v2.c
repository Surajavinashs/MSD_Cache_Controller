/*
Authors:
@Ajna Bindhu,
@Sai T Bodanki
@Suraj A Sathyanarayanan
@Tejas Chavan
*/

#include <stdio.h>
#include <stdlib.h>
#include "data_cache_functions.h"
#include "cache_parameters.h"


extern int way;
extern struct cacheline Data_Cache[D_SETS][D_WAY];

void MESI(int event,int index,unsigned long address)
{
	switch (event)
	{
	case D_L1_Read:
		switch (Data_Cache[index][way].MESI)
		{
		case I: {
			Data_Cache[index][way].MESI = S;
			fprintf(outfile, "Read from	L2 %lx\n", address);
			break;
		}
		case S: {
			fprintf(outfile, "read from %lx\n", address);
			break;
		}
		case E: {
			fprintf(outfile, "read from %lx\n", address);
			break;
		}
		case M: {
			fprintf(outfile, "read from %lx\n", address);
			break;
		}

		default: {
			fprintf(outfile, "INVAILD STATE");
			break;
		}
	}
	break;

	case D_L1_Write:
		switch (Data_Cache[index][way].MESI) {
		case I: {
			Data_Cache[index][way].MESI = E;
			fprintf(outfile, "Read for Ownership from L2 %lx\n", address);
			break;
		}

		case S: {
			Data_Cache[index][way].MESI = E;
			fprintf(outfile, "Write to L2 %lx\n", address);
			break;
		}

		case E: {
			Data_Cache[index][way].MESI = M;
			break;
		}

		case M: {
			break;
		}

		default: {
			fprintf(outfile, "INVAILD STATE");
			break;
		}
	}
		break;

	case I_L1_READ:
		switch (Data_Cache[index][way].MESI)
		{
		case I: {
			Data_Cache[index][way].MESI = S;
			fprintf(outfile, "Read from L2 %lx\n", address);
			break;
		}

		default: break;
		}
	break;

	int temp_way;

	case D_L2_Read:
	{
		for (temp_way = 0; temp_way < D_WAY  ; temp_way++)
		{
			if (Data_Cache[index][temp_way].TAG == tag)
				break;
		}

		switch (Data_Cache[index][temp_way].MESI)
		{
		case M:
		{
			Data_Cache[index][temp_way].MESI = S;
			fprintf(outfile, "Return data to L2 %lx\n", address);
		} break;
	
		case E:
		{
			Data_Cache[index][temp_way].MESI = S;
		}break;

		default: fprintf(outfile,"ILLEGAL COMMAND");
			break;
		}
	}
	break;

	case INVALIDATE:
	{
		for (int temp_way = 0; temp_way < D_WAY ; temp_way++)
		{
			if (Data_Cache[index][temp_way].TAG == tag)
			{
				if ((Data_Cache[index][temp_way].MESI == S) || (Data_Cache[index][temp_way].MESI == E))
				{
					Data_Cache[index][temp_way].MESI = I;
					fprintf(outfile, "Invalidating the line\n");
					break;
				}
				else
					fprintf(outfile,"ILLEGAL COMMAND");
			}
		}
	}
	break;
	
	default: {
		fprintf(outfile, "ILLEGAL COMMAND");
		break;
	}
  }
}
