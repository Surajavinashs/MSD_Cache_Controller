/*---------------------------------------------------------------------------------------------------------------------
Description:
Authors: Bindu Ajna
Bodanki Sai Teja
Chavan Tejas
Sathyanarayanan Suraj
---------------------------------------------------------------------------------------------------------------------*/

// Declaring Standard Libraries
#include <stdio.h>
#include <stdlib.h>
#include "cache_parameters.h"
#include "general_functions.h"
#include "instruction_cache_functions.h"
#include "data_cache_functions.h"

#define DEBUG_MODE

//File Acess
FILE *outfile;  		//	Output File pointer
FILE *infile;			//  Input File Pointer
const char *input;
const char *output;
//Data types
int event, address;
int d_rd, d_wr, i_rd = 0;
int i_hit = 0,d_hit=0;			// Variable for Hit and miss count initialized to 0
int i_miss = 0,d_miss=0;
int way;
int tag;
int line_size,index_size;


// Declaring Structure For Instruction Cache
struct cacheline Instr_Cache[I_SETS][I_WAY];
struct cacheline Data_Cache [D_SETS][D_WAY];

// Declaration of Main Function
int main(int argc, char * argv[])
{
	// I/O files are taken using Command Line arguments 
	// Case 1 : No file names are mentioned. 
	if (argc == 1)
	{
		printf("I/O files are not mentioned. Using default files as inputs and Outputs\n");
		input = "Cache_fill.txt";
		output = "output.txt";
	}
	// Case 2 : Only Input File name is provided. Default Output file is created.
	else if (argc == 2)
	{
		printf("Input file will be named as mentioned. Output file will be defaulted to output.txt\n");
		input = argv[1];
		output = "output.txt";
	}
	// Case 3 : Both Input and Output file names are mentioned		
	else
	{
		input = argv[1];
		output = argv[2];
	}
	// Opening Input and Output file in read and write mode respectively
	infile = fopen(input, "r");							// Read Mode
	outfile = fopen(output, "w"); 							// Write Mode 

	I_Clear_Cache();
	D_Clear_Cache();

    
	while ((fscanf(infile, "%d %x\n", &event, &address) != EOF))
	{

		// Split Address
        bits_cal();
		int index = +Index_Split(address);
		int tag_rem = (int) log2(line_size) + (int) log2(index_size);
        int tag_bits =  8*sizeof(address) - tag_rem;
		tag = address >> tag_rem;

        
        printf("line_size : %d ,index_bit_size : %d, line_bits: %d, index : %d, tag_rem : %d, tag :%d,tag_size:%d\n",line_size,(int) log2(index_size),(int) log2(line_size),index,tag_rem,tag,tag_bits);

		//Detect and report invalid event
		if ((event > 4) && (event < 8))
		{
			fprintf(outfile, "Invalid Event\n");
			continue;
		}
		//Detect reads
		else if (event == D_L1_Read)
		{
			d_rd++;
			if ((Data_Read(index, tag))) {
				d_hit++;
			}
			else {
				d_miss++;
			}
			MESI(event, index, address);
		}
		//Detect writes
		else if (event == D_L1_Write)
		{
			d_wr++;
			if ((Data_Read(index, tag))) {
				d_hit++;
			}
			else {
				d_miss++;
			}
			MESI(event, index, address);
		}
		// Detect Instruction read
		else if (event == I_L1_READ)
		{
			i_rd++;
			if ((Instruction_Read(index, tag))) {
				i_hit++;
			}
			else {
				i_miss++;
			}
		}


		// Data request from L2 (in response to snoop)
		else if (event == D_L2_Read)
		{


				MESI(event, index, address);
		}


		//Detect INVALIDATE command from L2
		else if (event == INVALIDATE)
		{
			MESI(event, index, address);
		}
		//Detect reset event
		else if (event == RESET)
		{
			I_Clear_Cache();
			D_Clear_Cache();
			continue;
		}
		//Detect cache display event 
		else if (event == PRINTALL)
		{
			printf("yet to design\n");
			//Cache_Display();
			continue;
		}


		//-------------------------------Print to output file-----------------------------------------------
			fprintf(outfile, "Index = %d\n", index);						//Print Event
			fprintf(outfile, "Tag = %d\n",tag);					//Print Address

				for (int way = 0; way < I_WAY; way++)
				{
					fprintf(outfile, "Contents for way :%d LRU :%d TAG: %d\n", way, Instr_Cache[index][way].LRU, Instr_Cache[index][way].TAG);
				}

				for (int way = 0; way < D_WAY; way++)
				{
					fprintf(outfile, "Contents for way :%d LRU :%d TAG: %d MESI: %d \n", way, Data_Cache[index][way].LRU, Data_Cache[index][way].TAG, Data_Cache[index][way].MESI);
				}
		
				float d_hit_ratio = ((float)(d_hit)) / ((float)(d_hit + d_miss));
				fprintf(outfile, "Hits : %d , miss : %d, Hit rate : %3f \n", d_hit,d_miss,d_hit_ratio);
			
	}
	
	float i_hit_ratio = ((float)(i_hit)) / ((float)(i_hit + i_miss));
	float d_hit_ratios = ((float)(d_hit)) / ((float)(d_hit + d_miss));

	//I_Statistics(i_hit, i_miss, i_hit_ratio);
	//D_Statistics(d_hit, d_miss, d_hit_ratio);
	fclose(infile);
	fclose(outfile);

	printf("\n-------------Instruction Cache Stats---------\n");
	printf(" Hits : %d \n", i_hit);
	printf(" Miss : %d \n", i_miss);
	printf(" Hit Ratio : %3f", i_hit_ratio);

	printf("\n-------------Data Cache Stats---------\n");
	printf(" Hits : %d \n", d_hit);
	printf(" Miss : %d \n", d_miss);
	printf(" Hit Ratio : %3f", d_hit_ratios);


	getchar();

}
