/*
 Authors:
 @Ajna Bindhu,
 @Sai T Bodanki
 @Suraj A Sathyanarayanan
 @Tejas Chavan
 */
#include <stdio.h>
#include "cache_parameters.h"

// Variable to declare MESI protocol
void MESI(int event, int index, int way, int address);
