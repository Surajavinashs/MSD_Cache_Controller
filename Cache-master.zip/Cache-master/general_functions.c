/*-----------------------------------------------------------------
instruction_cache_functions.c : Contails  functions for simulation
 					  of Instruction Cache.

 Authors:
 @Ajna Bindhu,
 @Sai T Bodanki
 @Suraj A Sathyanarayanan
 @Tejas Chavan
-------------------------------------------------------------*/
// Defining Required libraries

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

// Defining required functions files
#include "cache_parameters.h"
extern int event,line_size,index_size;
// Instruction cache Index and Byte select bits
//int Index_Bits = 14;//log2(I_INDEX);
//int Byte_Sel = 6;//log2(I_LINESIZE);

void bits_cal()
{
if(event==2)
{
    line_size = (int)I_LINESIZE;
    index_size = (int) I_SETS;
}
else
{
    line_size = (int)D_LINESIZE;
    index_size = (int) D_SETS;
}
}
//---------------Split Index Bits from the address--------------
// Splits or Masks the the Index Bits from the netire address 
int Index_Split (unsigned long address)
	{
		int i;
		int split = 1;								// Initializing split parameter to 1
		int index;
		address = address >> (int) log2(line_size);              // istream Operator Segregates Byte_Sel from the trace address
	// Now we can operate on our leftover address which is without the Byte_Sel bits
		for (i=0; i< log2(line_size); i++)
		{
			split = split *2;
		}
		index = address & (split-1);
		return index;
	}
