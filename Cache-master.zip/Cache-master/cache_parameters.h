/*
Description: The file contains the Parameter needed for the Cache

Authors: 
@Ajna Bindhu,
@Sai T Bodanki
@Suraj A Sathyanarayanan
@Tejas Chavan

*/


#ifndef _CACHE_FUNCTIONS
#define _CACHE_FUNCTIONS

#include <math.h>
#include <stdio.h>


//Instrucntion Cache Parameters

#define K 	 1024
#define Mega 1024*K

#define     I_CAPACITY    2*Mega
#define     I_WAY         2
#define     I_LINESIZE    64
#define     I_SETS        I_CAPACITY/(I_WAY*I_LINESIZE)

//Data Cache Parameters
#define     D_CAPACITY    4*Mega
#define     D_WAY         4
#define     D_LINESIZE    64
#define     D_SETS        D_CAPACITY/(D_WAY*D_LINESIZE)

//Printing Menu

#define		 MODE0			0
#define		 MODE1			1
#define		 DEBUG			2

//MESI Definitions

#define     M           3
#define     E           2
#define     S           1
#define     I           0

//Snoop Result types

#define     NOHIT           0 /* No hit */
#define     HIT             1 /* Hit */
#define     HITM            2 /* Hit to modified line */

#define     READ            1 /* Bus Read */
#define     WRITE           2 /* Bus Write */
#define     INVALIDATE      3 /* Bus Invalidate */
#define     RWIM            4 /* Bus Read With Intent to Modify */
#define     NOBUSOP         5 /* No Bus Operation */

//TRACE requests

#define     D_L1_Read       0 //L1 Data Read
#define     D_L1_Write      1 //L1 Data Write
#define     I_L1_READ       2 //L1 Instruction Read
#define     INVALIDATE      3 //Invalidate from L2
#define     D_L2_Read       4 //Data Request from L2 (Response to snoop)
#define     RESET           8 //Reset
#define     PRINTALL        9 //Print all valid cachelines,States

// structure for the status of a cache line
struct cacheline 
{
	int MESI;
	int LRU;
	int TAG;
}; 

#endif


