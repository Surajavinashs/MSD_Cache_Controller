/* ------------------------------------------------------------------
Header File for General_Functions.c

 Authors:
 @Ajna Bindhu,
 @Sai T Bodanki
 @Suraj A Sathyanarayanan
 @Tejas Chavan
-------------------------------------------------------------------*/
#include <stdio.h>
#include "cache_parameters.h"

//#define General_Functions
extern FILE *outfile;
extern struct cacheline Instr_Cache[I_SETS][I_WAY];
extern int i_hit, d_hit;

// Variable to Match tag bits
//int Match_Tag_Bits(int index, int tag, int *hit);

void I_updateLRU(int index, int way);

void I_Clear_Cache(void);

int I_Miss_Handler(int index, int tag);

int I_Hit_Check(int index, int tag);

int Instruction_Read(int index, int tag);

void I_Evict_Line_LRU(int index, int tag);

void I_Statistics(int hit, int miss, float hit_rate);
