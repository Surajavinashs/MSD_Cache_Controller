gcc -o cache main.c data_cache_functions.c instruction_cache_functions.c general_functions.c MESI_v2.c

./cache Cache_fill.txt output.txt 
